package Tp5;

public class Program {
	
	public static void main(String[] ags) {
		
		System.out.println(RecursiveFunctionsDaC.reverseString("Hello"));
		System.out.println(RecursiveFunctionsDaC.sumbinaryDigits("10101011"));
	}
}
