package Tp7.Collections;

import java.util.ArrayList;

public class Program {

	public static void main(String[] ags) {
		
	}
}
